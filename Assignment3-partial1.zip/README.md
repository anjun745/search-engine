# a3
Assignment 3 for CS121 Information Retrieval.
Milestones divided into folders.
