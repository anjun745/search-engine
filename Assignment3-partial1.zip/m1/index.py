import nltk

"""
Simple in-memory indexer:

procedure BUILDINDEX(D)
    indexHashTable = HashTable()
    n = 0
    for document in documents:
        n += 1
        T = Parse(document)
        # remove dupes from T
        for token in tokens:
            if indexHashTable.find(t) not in I:
                indexHashTable.find(t) = List<Posting>()
            indexHashTable.find(t).append(Posting(n))
    return I indexHashTable      
"""